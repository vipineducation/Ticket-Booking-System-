import json
from tabulate import tabulate
from ticket_booking.MODULES import file_manager
from ticket_booking.config import SHOWS_FILE
from ticket_booking.CORE import logs
from ticket_booking.config import LOG_FILE

new_data= file_manager.read_json(SHOWS_FILE)


wanted_keys=['id', 'title', 'category', 'timing','price']
filtered_data=[{k:show[k] for k in wanted_keys if k in show}
              for show in new_data]
print(tabulate(filtered_data, headers="keys", tablefmt="grid"))


# this function show seats number of specific show from user input id
def BookMyShow(new_data):
    while True:
        try:
          ShowId= int(input("Type the ID of the show you'd like to book: "))
        except ValueError:
          print("Invalid Input. Please select valid show ID .")
          continue
        match_found=False
        for show in new_data:
              if ShowId ==show['id']:
                match_found=True
                return show                
        if not match_found:
            print("Invalid Show Id.\nPlease select a valid show.")      
    

def book_seat(select_show):
    username= input("Enter Username:- ")
    match_found1=True
    while match_found1:
        try:  
         seat_Id1= input("Enter seat to book: ")
         seat_Id= seat_Id1.upper()
        except ValueError:
            print("❌ Invalid Seat")
            continue

        price=select_show["price"]
        id=select_show['id']
        seatid= seat_Id

        if seat_Id not in select_show["seats"]:
            print("There is no seat available in show..")
        elif select_show["seats"][seat_Id]=="booked":
            print("⚠ Seat already booked")
            status= "STATUS=FAILED | REASON=SEAT_BOOKED"
            data= logs.show_log(username, id, seatid, price, status ) 
            logs.save_log(LOG_FILE, data + "\n")               
        else:
            select_show["seats"][seat_Id]="booked"
            match_found1=False
            print(f"✅ Seat {seat_Id} successfully booked!")
            status= "STATUS=SUCCESS"


    return username, id, seatid , price, status


    
select_show=BookMyShow(new_data)
print(json.dumps(select_show, indent=4, sort_keys=True) ) 
username, id, seatid, price, status= book_seat(select_show)  
write_data= file_manager.write_json(SHOWS_FILE,new_data)

data= logs.show_log(username, id, seatid, price, status ) 
logs.save_log(LOG_FILE, data + "\n")



#ab mujhe status show krna hai failed and success ka 
                       