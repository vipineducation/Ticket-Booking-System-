from ticket_booking.config import LOG_FILE
from datetime import datetime

def show_log(user,id,seatid, price, status):
   date= datetime.now()
   current_time= date.strftime("%Y-%m-%d %I:%M %p")
   return f'{current_time} | "USER": {user}, | "SHOW ID": {id}, | "SEAT": {seatid}, | "PRICE": {price}, | {status}'
   

def save_log(LOG_FILE,save_new_log):
       with open(LOG_FILE, 'a') as log:
              log.write(save_new_log)
              


if __name__ == "__main__":
   save_new_log= show_log('VIPIN', 101, 'A1', 299)
   save_log(LOG_FILE, save_new_log)

