# main.py
from ticket_booking.CORE.booking_logic import BookMyShow, book_seat
from ticket_booking.MODULES import file_manager
from ticket_booking.config import SHOWS_FILE

def main():
# Load shows data
  new_data = file_manager.read_json(SHOWS_FILE)

# User selects show
  selected_show = BookMyShow(new_data)

# Show details
  import json
  print(json.dumps(selected_show, indent=4, sort_keys=True))

# User selects seat
  book_seat(selected_show)

# Save updated data back to JSON
  file_manager.write_json(SHOWS_FILE, new_data)

  # x=models.booking_show("user", "show_id", "seat", "price", "date")
  # print(x)
  if __name__ == "main":
     main()



#for run this program enter in terminal  python -m ticket_booking.main      