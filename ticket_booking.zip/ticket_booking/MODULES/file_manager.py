import json

def read_json(file_path):
    with open(file_path, 'r') as file:
        return json.load(file)
        


def write_json(file_path, data_to_save):
    with open(file_path, 'w') as file:
        json.dump(data_to_save, file, indent=4, sort_keys=True)
        
    
# In this step, we will use new_data to read the file first. 
# After loading the existing content, we will modify or add the specific data we want to write. 
# Finally, we will pass this updated data to the write_json function, 
#  which will overwrite the file with the complete, updated dataset

file_path=r'D:\Python\PY\ticket_booking\DATA\shows.json'
new_data=read_json(file_path)
write_data=write_json(file_path, new_data)  