def make_show(id, title, category, timing, price, seats):
    
    return {
            "id": id,
            "title": title,
            "category": category,
            "timing": timing,
            "price": price,
            "seats": seats
             
             }

def booking_show(user, show_id, seat, price, date):
    
    return  {
          "user": user,
          "show_id": show_id,
          "seat": seat,
          "price": price,
          "date": date
           }
