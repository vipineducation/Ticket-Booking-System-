from pathlib import Path

# Project root directory
BASE_DIR = Path(__file__).resolve().parent


DATA_DIR = BASE_DIR / "DATA"


# Data files
SHOWS_FILE = DATA_DIR / "shows.json"
BOOKINGS_FILE = DATA_DIR / "bookings.json"
LOG_FILE = DATA_DIR / "booking.log"
